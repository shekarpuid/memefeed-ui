import React from 'react';
import {Input} from 'native-base';
const TextInput = (props) => {
  return <Input {...props} />;
};

export default TextInput;
