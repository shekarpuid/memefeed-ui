import * as React from "react"
import { useApiRequest } from '../utils'
import { env } from "../env"
import { encode } from 'base-64'
import {View} from 'react-native'
import {Text} from 'native-base'

const Test = () => {
    return <Text>Testing...</Text>
}

export default Test