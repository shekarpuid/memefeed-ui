/*For API Base URL*/
export const env = {
    /* Dev */
    baseUrl : 'https://memefeed.app/meme_feed/', 
    // https://memefeed.app/meme_feed/users/handlelist
    // baseUrl : 'http://13.233.73.222:8000/', - Old one
    
    /* Production */
    // baseUrl : 'http://13.233.73.222:8000/'
    
    debug: false
}